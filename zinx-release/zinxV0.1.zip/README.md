---
title: "Zinx框架的学习"
date: 2022-01-10T10:14:32+08:00
tag: ["Go", "zinx"]
categories: ["Go"]
draft: true
---

# zinx 框架

开始学习 Go 语言实现的 zinx 框架。
ziface 定义一些接口层的方法

> 使用 go mod 管理, 初始化为 go mod init github.com/chaggle/zinx-study
> 并部署代码到 github.com 以及使用 go get 同步到本地 Gopath 的 github 包下！
